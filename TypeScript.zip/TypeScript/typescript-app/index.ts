//refrence/object type

//Type Class
class Customer{
    id:number;
    name:string;    // Can not we optional 
    address?:string; //Can we optional by using ?
}
function testLiteral(){
    let custmer:Customer ={
        id: 100,
        name: 'Prabhat'
    }

    console.log(`${custmer.id}  ${custmer.name}`);
}

testLiteral();

//Array
/* 
1   construcoter patter
let list: number[] =[1,2,3]
2   literal patter
let list:Array<> = [];
*/

function testArry(){
    //1 patter
    let list: number[] = [1,2,3]; //can not assign 'test' in array
    console.log(list);

    //2 pattern : using Generics
    let customerList:Array<Customer> =[
        {id:1, name:'Ram'},
        {id:2, name:'Shyam'},
        {id:3, name:'Mohan'}
    ]
    console.log(customerList);

    //tuple
    let x: [string, number];
    x =["hello", 10];
    //x=[5,"Hello"];

    console.log(x);

    //javascript style: any type

    let z: any;
    z=10;
    console.log(`With number ${z}`);
    z='Test';
    console.log(`With String ${z}`);
    z= true;
    console.log(`With Boolean ${z}`);

}

testArry();

//Functions


function sayHello(name:string, id?:number, age:number=1){
    //id is optional
    // age is optional with default value

    console.log(`${name}  ${id}  ${age}`);
}

sayHello('Prabhat', 10,15);
sayHello('Prabhat', 10);
sayHello('Prabhat');
//sayHello(10); error
//sayHello(); error


//return type


function sayHi(name:string, id?:number, age:number=1):string{
    //return id; error
    return `${name}  ${id}  ${age}`;
}
console.log(sayHi('Prabhat', 10,15));

//void function
function sayGreet():void{
    // return "Hello"; error
    console.log("Hello ");
}


//Object
class Employee{
    id: number;
    name?: string;
}
function printEmployee(emp:Employee) :Employee{
    return emp;
}

console.log(printEmployee({id:1, name:'Prabhat'}));


//Array

class Custm{

    id:number;
    name:string;
    address?:string;
}

function getCustomer(): Array<Custm>{
    let customerList:Array<Customer> =[
        {id:1, name:'Ram'},
        {id:2, name:'Shyam'},
        {id:3, name:'Mohan'}
    ]
    return customerList;

}

console.log(getCustomer());

//interface

/* 

*/

interface EmployeeInterface{
    id:number;
    name:string;
    address?: string;
}

function testInterface(){

    let emp : EmployeeInterface ={
        id: 1,
        name:'Prabhat'
        }
        console.log(emp);
}

testInterface();

/* 
Polymorphism
*/

interface Runnable{
    run():void;
}

interface Flyable{
    fly():void;
}

class Bird implements Flyable{
    fly():void{
        console.log('Bird flying!');
    }
}


function createBird(){
    let bird : Bird = new Bird();
         bird.fly();
}


class Flight implements Runnable, Flyable{
    run():void{
        console.log('Flight running!');
    }

    fly():void{
        console.log('Flight flying!');
    }
}


function createFlight(){
    let flight : Flight = new Flight();
    flight.run();
    flight.fly();
}

createFlight();
createBird();

function createFlightAndBird(){
    console.log("Super Programing");
    let flying : Flyable =null;
    flying = new Flight();
    flying.fly();
    flying  = new Bird();
    flying.fly();
}
createFlightAndBird();

// Access Modifiers
/* 
private
protected
public */

//Pattern 1
class Hero{
    id:number;
    private name:string;

    //pattern 2
    constructor(private add:string){
        this.add = add;
    }

    getId(){ return this.add; } //getter
}

function createHero(){
    let hero = new Hero('sagar');
    hero.id = 1; 
    //hero.name ='Prabhat'; Property 'name' is private and only accessible within class 'Hero'
    console.log(`${hero.id} ${hero.getId()}`);
}

createHero();


//Protected

class Person{
    protected name: string;
    constructor(name:string){
        this.name = name;
    }
}

class Student extends Person{
    private dept:string;
    constructor(name:string, dept:string){
            super(name);
            this.dept = dept;
    }

    public getSpeech(){
        return ` Hello, My name is ${this.name} Study in ${this.dept}`;
    }
}

function createStud(){
  let stud = new Student('Prabhat', 'MCA');
  console.log(stud.getSpeech());
}

createStud();


//Abstract Class

abstract class Animal{

    abstract sound():void;
    move():void{
        console.log('Can Walk....');
    }

}

class Dog extends Animal{
    sound():void{
        console.log('Can Sound....');
    }
    
}

function createAminal(){
    let animal: Animal = null;
    animal = new Dog();
    animal.sound();
    animal.move();
}

createAminal();


//User define generics
//Generics function
function userGeneric<T>(arg:T):T{
    return arg;
}

//with multiple

function userTwoGeneric<T,N>(arg:T, num:N):any{
    return `${arg} ${num}`;
}


function testGeneric(){
    let output;
    output = userGeneric<string>('Hello');
    console.log(`String ${output}`);

    output = userGeneric<number>(10);
    console.log(`Number ${output}`);

    output = userTwoGeneric<string, number>('Hello', 10);
    console.log(`Mix ${output}`);

    
}

testGeneric();


//Generics Classess

class GenericNumber<T>{
    zeroValue: T;
    add: (x:T, y:T) => T;
}

function testGenericClass(){
    let mygen =  new GenericNumber<number>();
    mygen.zeroValue =0;
    mygen.add = function(x, y) {return x + y;}; 
}

testGenericClass();

//Module (Working as ES6)
// Decoretore (Annotation in Java)