function testVariable(){
    let name:string = 'Prabhat';
    let salary:number = 100;
    let isWorking:boolean = true;    
    console.log(`${name} ${salary} ${isWorking}`);
}
testVariable();


class Person{

    color:string;
}
class Employee extends Person{

    name:string;
    id:number;

    constructor(name:string, id:number, color:string){
        super();
        this.name = name;
        this.id = id;
        this.color = color
    }
}

let emp = new Employee('Ram',201,'White');

console.log(`${emp.name} ${emp.id} ${emp.color}`);


let user = [
    {name:'Prabhat' , site: [
        {name:'facebook', path:'facebook.com'},
        {name:'gmail', path:'gmail.com'}]},
    {name:'Gaurav' , site: [
        {name:'facebook', path:'facebook.com'},
        {name:'gmail', path:'gmail.com'}]},
    {name:'Khuman' , site: [
        {name:'facebook', path:'facebook.com'},
        {name:'gmail', path:'gmail.com'}]},
    {name:'Anil' , site: [
        {name:'facebook', path:'facebook.com'},
        {name:'gmail', path:'gmail.com'}]}];
user.forEach(user => {
    console.log(`User Name: ${user.name}`);
    user.site.forEach(s => console.log(`Site Name: ${s.name} Site Path: ${s.path}`))
});