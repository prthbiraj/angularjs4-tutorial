//refrence/object type
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
//Type Class
var Customer = /** @class */ (function () {
    function Customer() {
    }
    return Customer;
}());
function testLiteral() {
    var custmer = {
        id: 100,
        name: 'Prabhat'
    };
    console.log(custmer.id + "  " + custmer.name);
}
testLiteral();
//Array
/*
1   construcoter patter
let list: number[] =[1,2,3]
2   literal patter
let list:Array<> = [];
*/
function testArry() {
    //1 patter
    var list = [1, 2, 3]; //can not assign 'test' in array
    console.log(list);
    //2 pattern : using Generics
    var customerList = [
        { id: 1, name: 'Ram' },
        { id: 2, name: 'Shyam' },
        { id: 3, name: 'Mohan' }
    ];
    console.log(customerList);
    //tuple
    var x;
    x = ["hello", 10];
    //x=[5,"Hello"];
    console.log(x);
    //javascript style: any type
    var z;
    z = 10;
    console.log("With number " + z);
    z = 'Test';
    console.log("With String " + z);
    z = true;
    console.log("With Boolean " + z);
}
testArry();
//Functions
function sayHello(name, id, age) {
    //id is optional
    // age is optional with default value
    if (age === void 0) { age = 1; }
    console.log(name + "  " + id + "  " + age);
}
sayHello('Prabhat', 10, 15);
sayHello('Prabhat', 10);
sayHello('Prabhat');
//sayHello(10); error
//sayHello(); error
//return type
function sayHi(name, id, age) {
    if (age === void 0) { age = 1; }
    //return id; error
    return name + "  " + id + "  " + age;
}
console.log(sayHi('Prabhat', 10, 15));
//void function
function sayGreet() {
    // return "Hello"; error
    console.log("Hello ");
}
//Object
var Employee = /** @class */ (function () {
    function Employee() {
    }
    return Employee;
}());
function printEmployee(emp) {
    return emp;
}
console.log(printEmployee({ id: 1, name: 'Prabhat' }));
//Array
var Custm = /** @class */ (function () {
    function Custm() {
    }
    return Custm;
}());
function getCustomer() {
    var customerList = [
        { id: 1, name: 'Ram' },
        { id: 2, name: 'Shyam' },
        { id: 3, name: 'Mohan' }
    ];
    return customerList;
}
console.log(getCustomer());
function testInterface() {
    var emp = {
        id: 1,
        name: 'Prabhat'
    };
    console.log(emp);
}
testInterface();
var Bird = /** @class */ (function () {
    function Bird() {
    }
    Bird.prototype.fly = function () {
        console.log('Bird flying!');
    };
    return Bird;
}());
function createBird() {
    var bird = new Bird();
    bird.fly();
}
var Flight = /** @class */ (function () {
    function Flight() {
    }
    Flight.prototype.run = function () {
        console.log('Flight running!');
    };
    Flight.prototype.fly = function () {
        console.log('Flight flying!');
    };
    return Flight;
}());
function createFlight() {
    var flight = new Flight();
    flight.run();
    flight.fly();
}
createFlight();
createBird();
function createFlightAndBird() {
    console.log("Super Programing");
    var flying = null;
    flying = new Flight();
    flying.fly();
    flying = new Bird();
    flying.fly();
}
createFlightAndBird();
// Access Modifiers
/*
private
protected
public */
//Pattern 1
var Hero = /** @class */ (function () {
    //pattern 2
    function Hero(add) {
        this.add = add;
        this.add = add;
    }
    Hero.prototype.getId = function () { return this.add; }; //getter
    return Hero;
}());
function createHero() {
    var hero = new Hero('sagar');
    hero.id = 1;
    //hero.name ='Prabhat'; Property 'name' is private and only accessible within class 'Hero'
    console.log(hero.id + " " + hero.getId());
}
createHero();
//Protected
var Person = /** @class */ (function () {
    function Person(name) {
        this.name = name;
    }
    return Person;
}());
var Student = /** @class */ (function (_super) {
    __extends(Student, _super);
    function Student(name, dept) {
        var _this = _super.call(this, name) || this;
        _this.dept = dept;
        return _this;
    }
    Student.prototype.getSpeech = function () {
        return " Hello, My name is " + this.name + " Study in " + this.dept;
    };
    return Student;
}(Person));
function createStud() {
    var stud = new Student('Prabhat', 'MCA');
    console.log(stud.getSpeech());
}
createStud();
//Abstract Class
var Animal = /** @class */ (function () {
    function Animal() {
    }
    Animal.prototype.move = function () {
        console.log('Can Walk....');
    };
    return Animal;
}());
var Dog = /** @class */ (function (_super) {
    __extends(Dog, _super);
    function Dog() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Dog.prototype.sound = function () {
        console.log('Can Sound....');
    };
    return Dog;
}(Animal));
function createAminal() {
    var animal = null;
    animal = new Dog();
    animal.sound();
    animal.move();
}
createAminal();
//User define generics
//Generics function
function userGeneric(arg) {
    return arg;
}
//with multiple
function userTwoGeneric(arg, num) {
    return arg + " " + num;
}
function testGeneric() {
    var output;
    output = userGeneric('Hello');
    console.log("String " + output);
    output = userGeneric(10);
    console.log("Number " + output);
    output = userTwoGeneric('Hello', 10);
    console.log("Mix " + output);
}
testGeneric();
//Generics Classess
var GenericNumber = /** @class */ (function () {
    function GenericNumber() {
    }
    return GenericNumber;
}());
function testGenericClass() {
    var mygen = new GenericNumber();
    mygen.zeroValue = 0;
    mygen.add = function (x, y) { return x + y; };
}
testGenericClass();
//Module (Working as ES6)
// Decoretore (Annotation in Java) 
