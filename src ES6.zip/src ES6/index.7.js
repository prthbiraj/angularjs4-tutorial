// Literal Patter

let Persone ={
    type : 'Insane'
}

let customer = {
    id:1,
    name:'Prabhat',
    clacGST:() => 100,
    //has a
    address: {
            city: 'sagar'
    }


}

//is a

customer.__proto__ = Persone;

customer.id =101;
console.log(` ${customer.type} ${customer.id} ${customer.name} ${customer.clacGST()} ${customer.address.city}` )

// Modularity:
