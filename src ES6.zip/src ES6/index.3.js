//Oprators

// == and ===

let x = 100;
let y = 100;
let z = "100";
let result = x == y;
let result1 = x == z;
let result2 = x === z;
console.log(`result ${result}`);
console.log(`result ${result1}`);
console.log(`result ${result2}`);

// OR 

let isWorking = true;
let hasProject = true;

let promotionStatus = isWorking || hasProject;
console.log(`Promeostion Status ${promotionStatus}`);

let name = 'Prabhat';//change with 0 or false or '0' 
let score = 80;
let gameStatus = name || score;
console.log(`Game Status ${gameStatus}`);

let myLocation = myLocation || 'Mumbai';
console.log(`My Location ${myLocation}`);

let hero;
let status = hero ? "Your are hero" : "Your are not hero";
console.log(`Are you Hero? : ${status}`);

// type of

let productPrice = 200;
let productName = 'IPhone';
console.log(typeof productPrice);
console.log(typeof productName)