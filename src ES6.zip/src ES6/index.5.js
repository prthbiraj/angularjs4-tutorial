//Function as litral

function add(a, b){
    return a + b;
}

//we can pass value in two ways
//first passing literal directly
console.log(add(10,20));


//second way passing variable having values

let x = 100;
let y = 200;
console.log(add(x,y));

//Pass function as litral ES5

//Passing function via variable patter
let hello = function(){
    console.log('Hello');
}

function sayHello(msg){  
    msg();  
}

sayHello(hello);

//direct literal pattern
sayHello(function(){
    console.log("Anonumus Function");
})

//with paramater

let hello1 = function(name){
//console.log('Hello');
return `Hello ${name}`;
}

function sayHello1(msg){  
   console.log( msg('Prabhat'));  
}

sayHello1(hello1);


//Pass function as litral ES6

let greetMe = message => message();
let welcome = () => console.log('Welcome ES6');
greetMe(welcome);

greetMe(() => console.log('Welcome'));

//Parameter and return type

let greetMe2 = message1 =>  console.log(message1('Prabhat')); //Arg

let welcome2 = name => `ES6 Welcome ${name}`; //return

greetMe2(welcome2); //pass function

greetMe2(name => `ES6 Welcome ${name}`); // pass Anonumus function