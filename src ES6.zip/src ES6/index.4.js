//functions

//Normal function..

function sayHello(){
    console.log("Hello Function");
}

//invocation
sayHello();

//Parameters

function sayHi(name = 'detault Name', address ='Sagar'){
    console.log(`Hi ${name} Address  ${address}`);
    return `Hello from return ${name}`;
}

sayHi('Prabhat', 'Pune');
console.log(sayHi());


// don't know the arg count.

function logger(){
    console.log(arguments);// Es5
}

logger('hi');
logger('Welcome', 'hai');

function loggerEs6(appname, ...arg){
    console.log(`${appname} ${arg}`);
}

loggerEs6('app','hi');
loggerEs6('appDesk','Welcome', 'hai')


//function as a litral ES 5
//patter 1

function sayGreetToMe(){
    console.log('patter 1: Hello');
}
sayGreetToMe();
//patter 2.1

function sayGreet(){
    console.log("patter 2.1: Good Morning");
}

let greet = sayGreet; // function literal
greet();

//patter 2.2

let greetMe = function sayGreetMe(){
    return 'patter 2.2: Hello Prabhat';
}

console.log(greetMe());

//patter 2.3 Anonomus function (without a Name)

let greetMeOnce = function(name){
    return `GreetMe ${name}`;
}

console.log(greetMeOnce('Prabhat'));


//function as a litral ES 6
//Arrow Function

let print = function(){
    console.log("Print ES 5");
}
print();

// => fate arrow
let printEs6 = () => {
    console.log("Print ES 6 Patter 1");
}
printEs6();

// function having single statement

let printEs62 = () =>console.log("Print ES 6 Patter 2");
printEs62();

//function arg

let Msg = (msg) => console.log(msg);
Msg('Hello 1');

//siplified arg

let Msg2 = msg =>  console.log(msg);
Msg2('Hello 2');

//fucntion having return value

let Msg3 = () => {
    return 'Hello 3';
};


console.log(Msg3());


//simplified return

let Msg4 = () => 'Hello 4';
console.log(Msg4());

//function having single arg and single return

let Msg5 = msg => msg;

console.log(Msg5('Hello 5'));


//Function having multi line

let Msg6 = (name='Prabhat', age = 28) => {
let msg = 'welcome';
return `${msg} ${name} ${age}`;
}
console.log(Msg6());

