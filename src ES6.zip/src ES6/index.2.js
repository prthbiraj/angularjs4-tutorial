// variable and literals

//number

var count =100;
console.log("Count is " + count);

//String

var name = 'Prabhat Singh Chouhan'; //" " and ' ' both are working same.
console.log("Name is "  + name);

// back tick notation `` (From ES6) - String template literal

var subject = `Angular`;
console.log("subject " + subject);


//user of back-tick
//------------------------------------------------------------------
//in ES5

var htmlDoc= "<html><head>" +
                "<titel></titel></head>" +
                "<body></body></html>";

console.log(htmlDoc);
//in ES6

htmlDoc=`<html><head>
<titel></titel></head>
<body></body></html>`;
console.log(htmlDoc);
//------------------------------------------------------------------
//in ES5 (Variable + string concatination)

var street = '10th street';
var city = ' mumbai';

var address = street + city; //es5
console.log("Address" +  address); //es5

var addr = `${street} ${city}`; //es6
console.log(`Address ${addr}`); //es6

//boolean

var isWorking = true;
console.log(`Is Working ${!isWorking}`);


//undefined

var score;
console.log(`Score is ${score}`);


//Nan

var totalScore = score *100;    //opration on undefined 
var totalScore1 = '#2333' * 100; // type parsing error
var totalScore2 = parseInt("$3581" , 0) * 100;

console.log(`Total Score ${totalScore}`);
console.log(`Total Score ${totalScore1}`);
console.log(`Total Score ${totalScore2}`);

//Infinity : divide by 0
var math = 80;
var avgMarks = math/0;
console.log(`Avg Marks ${avgMarks}`)


//let keyword

let hero = 'Prabhat Chouhan'; //es 6 and onword 
console.log(`Hero ${hero}`);

//const  like final in java

const pi = 3.14;
console.log(`Pi Value ${pi}`);

//pi = 90; // not possible to reassing 