/* 
export and import 
*/

import Welcome, {name,
    sayHello,
    Greeter} from './mylib'

let greeter = new Greeter();
let welcome = new Welcome();

console.log(`Name is ${name}`);
console.log(sayHello());

