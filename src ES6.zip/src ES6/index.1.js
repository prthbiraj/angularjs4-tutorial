
console.log('Hello JavaScript or ES6');