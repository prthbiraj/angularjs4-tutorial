/* 
Array
*/

//Constructoer patter

//string Array
let nameList = new Array('java', 'c', 'c++');

for (let i = 0; i < nameList.length; i++) {
    console.log(nameList[i]);
}

//Literal Pattern
// number array
let list = [0, 1, 3];

for (let i = 0; i < list.length; i++) {
    console.log(nameList[i]);
}

//object array
let employees = [{
    name: 'Ram', city: 'Ayodhay', language: [{
        lagName: 'Java',
        lagId: 101
    }]
},
{
    name: 'Shaym', city: 'Mathura', language: [{
        lagName: 'C',
        lagId: 103
    }]
},
{
    name: 'Radha', city: 'Barshana', language: [{
        lagName: 'C++',
        lagId: 102
    }]
}]

for (let i = 0; i < employees.length; i++) {
    console.log(`Name ${employees[i].name} City ${employees[i].city}`);
}

//for each ES5
employees.forEach(function (employee) {
    console.log(`Name ${employee.name} City ${employee.city}`);
})

//for each ES6
employees.forEach(employee => {
    console.log(`Name ${employee.name} City ${employee.city}`);
    employee.language.forEach(lang => console.log(`Language Id ${lang.lagId} Language Name ${lang.lagName}`));
});


