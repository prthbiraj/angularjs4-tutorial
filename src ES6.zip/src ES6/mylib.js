//sharing variable

//sharing variable
export let name = 'Prabhat';

// sharing function
export let sayHello = () => 'Hello';

//sharing class
export class Greeter{
    constructor(){
        console.log('Greeter is called!');
    }
}

export default class Welcome{
    constructor(){
        console.log('Welcome is called!');
    }
}