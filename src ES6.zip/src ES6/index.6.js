//OOP's 
//Declare class - es5

/* function Employee(){
    //Class name should be noun for devloper understanding.

    //instance variables
    this.id = 101;
    this.name = 'Prabhat Singh';
    this.address = 'Sagar';

    //instance methods

    this.calSalary = function(){
        return 1000000;
    }
} */
function Employee(id = 2, name = 'noName' , address = 'noAddress'){
    //Class name should be noun for devloper understanding.

    //instance variables
    this.id = id //101;
    this.name = name //'Prabhat Singh';
    this.address = address //'Sagar';

    //instance methods

    this.calSalary = function(){
        return 1000000;
    }
}
//class calling
/* 
    Employee emp = new Employee(); Java, C#
    let em = new Employee();    JS
*/
/* let emp = new Employee();
console.log(`Employee id : ${emp.id} Name : ${emp.name} Address : ${emp.address} Salary is $${emp.calSalary()}`); */

let emp = new Employee(1, 'sir', 'chennai');
console.log(`Employee id : ${emp.id} Name : ${emp.name} Address : ${emp.address} Salary is $${emp.calSalary()}`);

//Declare class - es6

class Customer{

    //cunstructor

    constructor(id = 0, name ='noName'){
        this.id = id;
        this.name = name
    }

    //instance variables using Hard Coded
    id = 100;
    name = 'Prabhat Thakur';

    //instance Method

    calculateGST(){
        return 100*(18/100);
    }
}

//Object Creation..
let cust = new Customer();
console.log(`Customer Id ${cust.id} Name ${cust.name} GST ${cust.calculateGST()}`);

//instance variables after Object creation
cust.name = 'Krishna';
console.log(`Customer Id ${cust.id} Name ${cust.name} GST ${cust.calculateGST()}`);


//instance variables Constructor
let cust1 = new Customer('1', 'Sir');
console.log(`Customer Id ${cust1.id} Name ${cust1.name} GST ${cust1.calculateGST()}`);



//Hierarchy ES5
/*
    Has-A : 
    Is-A : inheritance
*/

function Address(street = 'noStreet', city = 'noCity'){
    this.street = street;
    this.city = city;    
}

function Student(rollno = 0, name = 'noName' , address){
    this.rollno=rollno;
    this.name = name;
    this.address = address;
}

let add = new Address('','Sagar')
let stud = new Student(101,'Prabhat',add);

console.log(` Student RollNo ${stud.rollno} Name ${stud.name} Address ${stud.address.city}`);


//Hierarchy ES6
/*
    Has-A : 
    Is-A : inheritance
*/

class AddressES6{
    constructor(street = 'noStreet', city = 'noCity'){
        this.street = street;
        this.city = city;    
    }
}

class StudentES6{
    constructor(rollno = 0, name = 'noName' , address){
        this.rollno=rollno;
        this.name = name;
        this.address = address;
    }    
}

let add1 = new AddressES6('near ram mandir','Jaunpur');

let stud1 = new StudentES6(101,'Ajay',add1);

console.log(` Student RollNo ${stud1.rollno} Name ${stud1.name} Address ${stud1.address.street} ${stud1.address.city}`);


//inheritance

//ES5
function Animal(){
    this.type='';
}

function Dog(){
    this.color = 'Black';
}

let dog = new Dog();
//explicit inheritance

dog.__proto__ = new Animal();
console.log(dog);
console.log(`Dog Color ${dog.color}`);

dog.color = 'Red';
dog.type = 'Domistic Animal';

console.log(`Dog Color ${dog.color} Type ${dog.type}`);


//ES6

class Bird{
    constructor(){
        this.color = 'Black & White';
        console.log("Parent Class Constructore");
    }

    eat(){
        return 'Bird Eat';
    }
}

class Egale extends Bird{
    constructor(){
        super();
        this.name='Egale';
        super.color = 'Green';
    }
    //override
    eat(){
        return 'Egale Eat';
    }
}

let egl = new Egale();

console.log(egl);
console.log(`Name ${egl.name} color ${egl.color} Eat ${egl.eat()}`);


//Static key word

class Message{

    static msg = "Success";
    static todo(){
        return 'Done';
    }
}

console.log(`Static Variable ${Message.msg} Static Method ${Message.todo()}`);

//Poly
//Globle Scope


//Local or private Scope

function funName(){
    let val = 100; // local variable
}

function ClassName(){
    let val = 200; //Private variable
    this.val1 = 100;

    let printVal = function(){
        return val;
    };
}

let cName = new ClassName();
console.log(`${cName.val1} ${cName.printVal}`); //${cName.val}  

//block scope

function sayHello(name){
    if(name){
        //var msg =   `Hello ${name}`;
        let msg =   `Hello ${name}`;
    }
    return msg;
}

console.log(sayHello('Prabhat'));
//console.log(sayHello()); // error  not defined  no-undef


//needs to complet