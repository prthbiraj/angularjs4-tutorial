import 'rxjs/add/operator/switchMap';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { Location } from '@angular/common';
import { Hero } from './hero';
import { HeroService } from './app.hero.service';

@Component({
    selector: 'app-herodetail',
    templateUrl: 'app.heroid.detail.component.html',
})
export class HeroIdDetailCompnent implements OnInit{

    hero: any;
    
        constructor(
            private heroService: HeroService,
            private route: ActivatedRoute,
            private location: Location
        ) { }
    
        ngOnInit(): void {
            this.route.paramMap
                .switchMap((params: ParamMap) =>
                this.heroService.getHeroById(+params.get('id')))
                .subscribe(hero => this.hero = hero);
        }
    
        goBack(): void {
            this.location.back();
        }
    
}