/* 
  Module Creation
  
*/

import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { EmployeeComponent } from './app.employee.component';
import { HeroComponent } from './app.hero.component';
import { HeroService } from './app.hero.service';
import { HeaderComponent } from './app.header.component';
import { HeroDetailsComponents} from './app.herodetails.component';
import { HeroDescriptionComponant } from './app.herodescr.component';
import { ExponentialStrenghthPipe } from './app.pipe.hero';
import { HighlightDirective } from './app.herohighlight.directive';
import { AppRoutingModule } from './app.routing.module';
import { DashboardComponenet } from './app.dashboard.component';
import { SkillsComponent } from "./app.hero.skilss.component"
import {FlyingComponent} from "./app.hero.flying.component"
import {ShootingComponent} from "./app.hero.shooting.component"
import { HeroIdDetailCompnent } from "./app.heroid.detail.component";


@NgModule({
  declarations : [AppComponent,EmployeeComponent, HeroComponent, HeaderComponent
  , HeroDetailsComponents, HeroDescriptionComponant, ExponentialStrenghthPipe,
  HighlightDirective, DashboardComponenet, SkillsComponent, FlyingComponent , 
  ShootingComponent,HeroIdDetailCompnent], // for view objects
  imports:[],    // for module objects
  providers:[],   // for Shared service bojects
  bootstrap: []
})


export class AppHeroModule{
}