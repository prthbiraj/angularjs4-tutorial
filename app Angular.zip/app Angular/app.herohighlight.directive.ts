import { Directive, ElementRef, HostListener } from "@angular/core";





@Directive({selector:'[highlightDirective]'})
export class HighlightDirective{

 constructor(private element:ElementRef){
     element.nativeElement.style.backgroundColor = 'lightBlue';
 }
 @HostListener('mouseenter') onMouseEnter(){
    this.element.nativeElement.style.backgroundColor = 'Pink';
 }

 @HostListener('mouseleave') onMouseLeave(){
    this.element.nativeElement.style.backgroundColor = 'lightBlue';
 }
}