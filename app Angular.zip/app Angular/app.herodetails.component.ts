/* Hero details componenet
 */

import {Component, Input} from '@angular/core';
import { Hero } from './hero';

 @Component({
    selector:'app-hero-details',
    styleUrls: ['app.heros.component.css'],
    template:`<div *ngIf="hero">
        <span class="badge">{{hero.id | exponentialStrenghthPipe:1}}</span> 
        {{hero.name | uppercase}}</div>`
 })
 export class HeroDetailsComponents{
        @Input("heroObj")
        hero:Hero;
 }