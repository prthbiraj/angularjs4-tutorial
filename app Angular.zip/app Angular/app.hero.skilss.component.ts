import { Component } from "@angular/core";





@Component({
selector: 'app-heroskills',
template:`<h1>Hero Skills</h1>
            <nav>
            <a [routerLink]="['./shooting']">Shooting</a>
            <a [routerLink]="['./flying']">Flying</a>
            </nav>
            <router-outlet></router-outlet>`
})
export class SkillsComponent {

}