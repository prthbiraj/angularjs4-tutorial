import { Component } from '@angular/core';
@Component({
    selector: 'app-heroshooting',
    template: `<h1>Hero Shooting</h1>
               `

})
export class ShootingComponent {

}
