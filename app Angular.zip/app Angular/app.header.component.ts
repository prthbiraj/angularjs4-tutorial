import { Component, Input } from '@angular/core';

@Component({
selector:'app-header',
template : `<h1  highlightDirective [style.color] ="isSpecial ? 'red' : 'green'"
                class="display-3">{{title}}!</h1>`
})

export class HeaderComponent{
    @Input() //bind the variable into user difine tag
    title: string;
    isSpecial:boolean = false; //style binding
}

