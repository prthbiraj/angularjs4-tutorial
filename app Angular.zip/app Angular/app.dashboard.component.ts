import { Component, OnInit } from '@angular/core';
import { Hero } from './hero';
import { HeroService } from './app.hero.service';

@Component({
    selector: 'app-dashboard',
    templateUrl: 'app.dashboard.component.html'
})
export class DashboardComponenet implements OnInit {
    title: string = 'Dashboard';
    heroes: Hero[] = [];
    constructor(private heroService: HeroService) { }

    ngOnInit(): void {
    this.heroService.getHerosAsyn()
            .then(heroes => this.heroes = heroes.slice(1, 5));
    }
}