import { Component,Input } from '@angular/core';
import {Hero} from './hero'

@Component({

    selector: 'app-herodecs',
    template: `<div class="col-md-8" *ngIf="selectedHero">
                <h1>Selected Hero {{selectedHero.name}}</h1>   
                <button [disabled]="false">View</button> 
                
                </div>`

})
export class HeroDescriptionComponant{
    @Input()
    selectedHero: Hero;

}

