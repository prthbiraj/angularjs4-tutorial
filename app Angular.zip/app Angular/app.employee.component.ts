/* User Defind component */

import { Component } from '@angular/core';
import { Employee } from './Employee'

@Component({
    selector: 'app-employee',
    template: `<div>
        <h5>Employee Id :{{employees.empId}}</h5>
        <h5>Employee Name :{{employees.empName}}</h5>
        <h5>Employee Salary :{{employees.empSay}}</h5>
    </div>`
})

export class EmployeeComponent{
    employees:Employee ={empId:101, empName:'Prabhat',  empSay:1050410};
}