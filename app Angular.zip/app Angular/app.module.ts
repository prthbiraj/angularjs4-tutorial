/* 
  Module Creation
  
*/

import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { EmployeeComponent } from './app.employee.component';
import { HeroComponent } from './app.hero.component';
import { HeroService } from './app.hero.service';
import { HeaderComponent } from './app.header.component';
import { HeroDetailsComponents} from './app.herodetails.component';
import { HeroDescriptionComponant } from './app.herodescr.component';
import { ExponentialStrenghthPipe } from './app.pipe.hero';
import { HighlightDirective } from './app.herohighlight.directive';
import { AppRoutingModule } from './app.routing.module';
import { DashboardComponenet } from './app.dashboard.component';
import { SkillsComponent } from "./app.hero.skilss.component"
import {FlyingComponent} from "./app.hero.flying.component"
import {ShootingComponent} from "./app.hero.shooting.component"
import { HeroIdDetailCompnent } from "./app.heroid.detail.component";
import { HttpClientModule } from "@angular/common/http";
import { FormsModule } from "@angular/forms";
import {HeroFormComponent } from './app.hero.form.componenet';

@NgModule({
  declarations : [AppComponent,EmployeeComponent, HeroComponent, HeaderComponent
  , HeroDetailsComponents, HeroDescriptionComponant, ExponentialStrenghthPipe,
  HighlightDirective, DashboardComponenet, SkillsComponent, FlyingComponent , 
  ShootingComponent,HeroIdDetailCompnent,HeroFormComponent], // for view objects
  imports:[BrowserModule, AppRoutingModule, HttpClientModule, FormsModule],    // for module objects
  providers:[HeroService],   // for Shared service bojects
  bootstrap: [AppComponent]
})


export class AppModule{
}