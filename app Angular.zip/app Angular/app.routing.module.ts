import { NgModule, Component } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { HeroDetailsComponents } from './app.herodetails.component'
import { DashboardComponenet } from './app.dashboard.component';
import { CommonModule } from "@angular/common";
import { HeroComponent } from "./app.hero.component";
import { SkillsComponent } from "./app.hero.skilss.component";
import {FlyingComponent} from "./app.hero.flying.component";
import {ShootingComponent} from "./app.hero.shooting.component";
import { HeroIdDetailCompnent } from "./app.heroid.detail.component";
import { HeroFormComponent } from "./app.hero.form.componenet";

const routers : Routes = [
    {path: '', component: HeroComponent},
    {path: 'heroes', component: HeroComponent},
    {path: 'dashboard', component: DashboardComponenet},
    {path: 'detail/:id', component: HeroIdDetailCompnent},
    {
        path: 'skills', component: SkillsComponent,
        children: [
            {
                path: '', redirectTo: 'shooting', pathMatch: 'full'
            },
            {
                path: 'flying', component: FlyingComponent
            },
            {
                path: 'shooting', component: ShootingComponent
            }
        ]
    },
    {path: 'heroform', component: HeroFormComponent}
];

@NgModule({
    declarations:[],
    imports:[CommonModule, RouterModule.forRoot(routers)], // inject router module with configuration
    providers:[],
    exports:[RouterModule] // for sub Module

})

export class AppRoutingModule{
// General Module class is empty class
}