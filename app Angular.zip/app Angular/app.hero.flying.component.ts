import { Component } from '@angular/core';
@Component({
    selector: 'app-heroflying',
    template: `<h1>Hero Flying</h1>
               `

})
export class FlyingComponent {

}