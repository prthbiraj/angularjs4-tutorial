
import { Injectable } from '@angular/core';
import { Hero } from './hero';
import { HttpClient} from '@angular/common/http'
import { Observable } from 'rxjs/Observable'

@Injectable()
export class HeroService{
   
    //object
   private hero: Hero = {
        id: 1,
        name: 'Rubber Man'
    }; 

    private heros :Hero[] = [{ id: 1,name: 'Shree Ram'},
                             { id: 2,name: 'Shree Krishan'},
                             { id: 3,name: 'Hanuman'},
                             { id: 4,name: 'Shree Laxman'},
                             { id: 5,name: 'Shree Bharat'},
                             { id: 6,name: 'Shree Satrughan'},
                             { id: 7,name: 'Shree Baldau'},
                             { id: 8,name: 'Shree Vishnu'},
                             { id: 9,name: 'Shree Shiv'},
                             { id: 10,name: 'Shree Arjun'},
                             { id: 11,name: 'Shree Bheem'},
                             { id: 12,name: 'Shree Dronacharya'},
                             { id: 13,name: 'Shree Shurya'},
                             { id: 14,name: 'Shree Chandrma'},
                             { id: 15,name: 'Shree Gautam'},
                             { id: 16,name: 'Shree Vivekanand'},
                             { id: 17,name: 'Shree Dhruv'},
                             { id: 18,name: 'Shree Prahalad'},
                             { id: 19,name: 'Shree Karna'}];

    heroesUrl = 'http://localhost:8081/api/heroes';

    constructor(private http:HttpClient){}


    //syn api to return hero
      getHero():Hero{          
          return this.hero;
      }

      //Asyn api to return hero
      getHeroAsyn():Promise<Hero>{
            return new Promise(resolve => {
                setTimeout( () => resolve(this.hero), 5000);
            });
      }

   //Asyn api to return array of hero
    getHerosAsyn():Promise<Hero[]>{
                return new Promise(resolve => {
                    setTimeout( () => resolve(this.heros), 200);
                });
          }

  getHeroById(id: number) :Promise<Hero>{
      return this.getHerosAsyn()
      .then(heroes => heroes.find(hero => hero.id === id));
  }

  /* Get Heroes from the server */
  getHeroesByHttp(): Observable<Hero[]>{
      return this.http.get<Hero[]>(this.heroesUrl);
  }


}