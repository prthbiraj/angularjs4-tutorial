/* User Defind component */

import { Component, OnInit } from '@angular/core';
import { HeroService } from './app.hero.service'
import { Hero } from './hero';

@Component({
    selector: 'app-hero',
    templateUrl: 'app.heros.component.html',
    styleUrls: ['app.heros.component.css']
    //providers: [HeroService]// Inject Service

})

export class HeroComponent implements OnInit{
    // Construtor Injection
    hero:Hero;
    heros:Hero[];
    selectedHero;
    constructor(private heroService:HeroService){       
    }

    ngOnInit(){
    //sync
    //this.hero = this.heroService.getHero();                
                
    //console.log(this.hero.id);             
    //Async
     //this.heroService.getHeroAsyn().then(hero => this.hero= hero);
     //this.heroService.getHerosAsyn().then(heros => this.heros= heros);
     this.heroService.getHeroesByHttp().subscribe((heroes => this.heros = heroes));
    }


    //event listener 

    onClick(hero){
            console.log(hero);
            this.selectedHero = hero;
    }
}