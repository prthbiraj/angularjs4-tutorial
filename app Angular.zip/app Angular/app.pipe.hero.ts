import { Pipe, PipeTransform } from "@angular/core";




@Pipe({name : 'exponentialStrenghthPipe'})
export class ExponentialStrenghthPipe implements PipeTransform{

    //Override : for implement pipe logic
    transform(val:number, exponent: string):number{
            const exp = parseFloat(exponent);
            return Math.pow(val, isNaN(exp) ? 1 : exp);
    }

}