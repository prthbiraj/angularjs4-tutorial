/* 
  Componenet Creation
  */
import { Component } from '@angular/core';
import { Hero } from './hero';

@Component({
  selector :'app-root',
  templateUrl : 'app.component.html',
})

export class AppComponent {
 
}