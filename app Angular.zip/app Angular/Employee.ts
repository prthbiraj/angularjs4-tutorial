export class Employee{
    empId:number;
    empName:string;
    empSay:number;
}